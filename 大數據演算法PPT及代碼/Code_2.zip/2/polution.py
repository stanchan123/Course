#!/usr/bin/python
# -*- encoding: utf-8


import numpy as np
import matplotlib as mpl
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import BaggingRegressor
import warnings
warnings.filterwarnings('ignore')

if __name__ == "__main__":
    mpl.rcParams['font.sans-serif'] = [u'simHei']
    mpl.rcParams['axes.unicode_minus'] = False

    # read_data()
    data = pd.read_csv('PM2.5.csv', header=0)   # C0911.csv, C0904.csv
    x = data['PM2.5'].values
   # print x

    # 异常检测
    width = 30
    delta = 10
    eps = 500
    N = len(x)
    p = []
    abnormal = []
    for i in np.arange(0, N-width, delta):
        s = x[i:i+width]
        p.append(np.ptp(s))   #最大值与最小值之差
        if np.ptp(s) > eps:
            abnormal.append(range(i, i+width))
    abnormal = np.unique(abnormal)
    plt.figure(facecolor='w')
    plt.plot(p, lw=1)
    plt.grid(b=True)
    plt.title(u'固定间隔$PM2.5$差值', fontsize=18)
    plt.xlabel(u'时间', fontsize=16)
    plt.xlabel(u'差值', fontsize=16)
    plt.show()

    plt.figure(figsize=(18, 7), facecolor='w')
    plt.subplot(131)
    plt.plot(x, 'g-', lw=1, label=u'原始数据')
    plt.title(u'实际PM2.5数据', fontsize=18)
    plt.legend(loc='upper right')
    plt.grid(b=True)

    plt.subplot(132)
    t = np.arange(N)
    plt.plot(t, x, 'g-', lw=1, label=u'原始数据')
    plt.plot(abnormal, x[abnormal], 'ro', markeredgecolor='g', ms=3, label=u'异常值')
    plt.legend(loc='upper right')
    plt.title(u'异常检测', fontsize=18)
    plt.grid(b=True)

    # 异常校正(预测)
    plt.subplot(133)
    select = np.ones(N, dtype=np.bool)
    select[abnormal] = False
    t = np.arange(N)
    dtr = DecisionTreeRegressor(criterion='mse', max_depth=10)
    br = BaggingRegressor(dtr, n_estimators=10, max_samples=0.3)
    br.fit(t[select].reshape(-1, 1), x[select])
    y = br.predict(np.arange(N).reshape(-1, 1))
    y[select] = x[select]
    plt.plot(x, 'g--', lw=1, label=u'原始值')    # 原始值
    plt.plot(y, 'r-', lw=1, label=u'校正值')     # 校正值
    plt.legend(loc='upper right')
    plt.title(u'异常值校正', fontsize=18)
    plt.grid(b=True)

    plt.tight_layout(1.5, rect=(0, 0, 1, 0.95))
    plt.suptitle(u'PM2.5的异常值检测与校正', fontsize=22)
    plt.show()
