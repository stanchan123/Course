# -*- coding: utf-8 -*-


from os import path
import re
import requests
import warnings
warnings.filterwarnings('ignore')

def fetch_sina_news():
    # PATTERN = re.compile('.shtml" target="_blank">(.*?)</a><span>(.*?)</span></li>')
    PATTERN = re.compile('"title":(.*?),')
    # BASE_URL = "http://roll.news.sina.com.cn/news/gnxw/gdxw1/index_"
    BASE_URL = 'https://feed.mix.sina.com.cn/api/roll/get?pageid=153&lid=2509&k=&num=50&page=1&r=0.660965026394422&callback=jQuery31107511096377082196_1546176337579&_=1546176337582'
    # MAX_PAGE_NUM = 10
    with open('subjects.txt', 'w', encoding='utf-8') as f:
        #for i in range(1, MAX_PAGE_NUM):
            #print('Downloading page #{}'.format(i))
            # r = requests.get(BASE_URL + str(i)+'.shtml')
            r = requests.get(BASE_URL)
            # r.encoding='gb2312'
            # data = r.text
            data = r.text.encode('utf-8').decode('unicode-escape')
            
            p = re.findall(PATTERN, data)
            
            for s in p:
                # f.write(s[0])
                f.write(s+"\n")
            # time.sleep(5)

if __name__ == "__main__":
    fetch_sina_news()
