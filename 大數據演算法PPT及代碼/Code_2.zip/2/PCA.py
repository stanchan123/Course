# -*- coding:utf-8 -*-


import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, SelectPercentile, chi2
from sklearn.linear_model import LogisticRegressionCV
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import PolynomialFeatures
from sklearn.manifold import TSNE
import matplotlib as mpl
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from sklearn import datasets
import warnings
warnings.filterwarnings('ignore')

if __name__ == '__main__':
    stype = 'pca'
    iris = datasets.load_iris()
    x = iris.data
    y = iris.target
    pca = PCA(n_components=2, whiten=True, random_state=0)
    x = pca.fit_transform(x)
    print('各方向方差：', pca.explained_variance_)
    print('方差所占比例：', pca.explained_variance_ratio_)
    x1_label, x2_label = u'组分1', u'组分2'
    title = u'鸢尾花数据PCA降维'

    print(x[:5])
    cm_light = mpl.colors.ListedColormap(['#BCEE68', '#FFB5C5', '#C1CDCD'])
    cm_dark = mpl.colors.ListedColormap(['#228B22', '#B22222', '#5CACEE'])
    mpl.rcParams['font.sans-serif'] = u'SimHei'
    mpl.rcParams['axes.unicode_minus'] = False
    plt.figure(facecolor='w')
    plt.scatter(x[:, 0], x[:, 1], s=30, c=y, marker='o', cmap=cm_dark)
    plt.grid(b=True, ls=':')
    plt.xlabel(x1_label, fontsize=14)
    plt.ylabel(x2_label, fontsize=14)
    plt.title(title, fontsize=18)
    # plt.savefig('1.png')
    plt.show()