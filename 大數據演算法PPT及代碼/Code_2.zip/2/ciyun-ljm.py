import wordcloud as wc
import matplotlib.pylab as plb
import jieba
from PIL import Image
from numpy import array
path="./subjects.txt"
data=open(path,"r",encoding="utf-8").read()
cutdata=jieba.cut(data)
alldata=""
'''词语1 词语2 词语3'''
for i in cutdata:
    alldata=alldata+" "+str(i)
font=r"C:\WINDOWS\Fonts\simhei.ttf"
#读图片
cat=Image.open("./cat.png")
#图片转数组
catarray=array(cat)
mywc=wc.WordCloud(collocations=False, font_path=font,mask=catarray,background_color="white").generate(alldata)
plb.imshow(mywc)
plb.show()
