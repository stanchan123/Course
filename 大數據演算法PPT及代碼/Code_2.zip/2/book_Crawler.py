

import requests
from bs4 import BeautifulSoup
import re
import warnings
warnings.filterwarnings('ignore')
s = 0
r = requests.get('https://book.douban.com/subject/3259440/comments/')
soup = BeautifulSoup(r.text, 'lxml')

pattern = soup.find_all('span', 'short')
out = open("./bookComments.txt","w",encoding="utf-8")
for item in pattern:
    print(item.string)
    out.write(item.string+"\n")

pattern_s = re.compile('<span class="user-stars allstar(.*?) rating"')
p = re.findall(pattern_s, r.text)
for star in p:
    s += int(star)
print(s)