#!/usr/bin/python
# -*- coding:utf-8 -*-

import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import LinearRegression
from sklearn import datasets
import warnings
warnings.filterwarnings('ignore')

boston = datasets.load_boston()
x  = boston.data
y = boston.target
print('样本个数：%d, 特征个数：%d' % x.shape)
print(y.shape)
y = y.ravel()

mpl.rcParams['font.sans-serif'] = [u'simHei']
mpl.rcParams['axes.unicode_minus'] = False


plt.figure(facecolor='w', figsize=(9, 8))
plt.subplot(311)
plt.plot(x[:,5], y, 'ro')
plt.title('住宅的平均房间数')
plt.grid()
plt.subplot(312)
plt.plot(x[:,12], y, 'g^')
plt.title('低收入人群比例')
plt.grid()
plt.subplot(313)
plt.plot(x[:,7], y, 'b*')
plt.title('到5个波士顿就业中心的加权距离')
plt.grid()
plt.tight_layout()
plt.show()

x = x[:,[5,7,12]]
x_train, x_test, y_train, y_test = train_test_split(x, y, train_size=0.7, random_state=0)
linreg = LinearRegression()
model = linreg.fit(x_train, y_train)
print('开始建模...')
model.fit(x_train, y_train)
print(model)
print(linreg.coef_, linreg.intercept_)

order = y_test.argsort(axis=0)
y_test = y_test[order]
x_test = x_test[order, :]
y_pred = model.predict(x_test)
r2 = model.score(x_test, y_test)
mse = mean_squared_error(y_test, y_pred)
print('R2:', r2)
print('均方误差：', mse)

t = np.arange(len(y_pred))
plt.figure(facecolor='w')
plt.plot(t, y_test, 'r-', lw=2, label='真实值')
plt.plot(t, y_pred, 'g-', lw=2, label='估计值')
plt.legend(loc='best')
plt.title('波士顿房价预测', fontsize=18)
plt.xlabel('样本编号', fontsize=15)
plt.ylabel('房屋价格', fontsize=15)
plt.grid()
plt.show()


