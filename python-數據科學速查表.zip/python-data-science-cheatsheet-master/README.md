# 数据科学文献
* DataCamp的Pandas速查表-中文版
* Figure Eight的2018年数据科学家报告-中文版
